export interface User{

    username:string;
    firstname:string;
    lastname:string;
    age:number;
    gender:string;
    contact:number;
    email:string;
    password:string;
    branch:string;
    status:String;
}
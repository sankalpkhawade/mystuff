package com.cognizant.Vehicle_RS.repository;


import org.springframework.data.repository.CrudRepository;

import com.cognizant.Vehicle_RS.model.Role;



public interface RoleRepository extends CrudRepository<Role, Integer> {

}

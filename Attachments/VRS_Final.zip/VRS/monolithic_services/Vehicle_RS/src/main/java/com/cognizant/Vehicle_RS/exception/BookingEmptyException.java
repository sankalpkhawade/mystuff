package com.cognizant.Vehicle_RS.exception;

public class BookingEmptyException extends Exception {

}

package com.cognizant.Vehicle_RS.exception;

public class UserAlreadyExistsException extends Exception {

}

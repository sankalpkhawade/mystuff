package com.cognizant.Vehicle_RS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleRsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleRsApplication.class, args);
	}

}
